package Spring_Data_JPA_Quick_Example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaQuickExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaQuickExampleApplication.class, args);
	}

}
