package Difference_Between_JPA_Hibernate_SpringDataJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DifferenceBetweenJpaHibernateSpringDataJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DifferenceBetweenJpaHibernateSpringDataJpaApplication.class, args);
	}

}
