package Difference_Between_JPA_Hibernate_SpringDataJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DifferenceBetweenJpaHibernateSpringDataJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
